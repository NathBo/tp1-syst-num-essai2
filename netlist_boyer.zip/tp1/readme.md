Pour compiler, lancer la commande suivante :
ocamlbuild netlist_simulator.byte

Pour lancer sur la netlist sur le fichier exemple.net, lancer la commande :
./netlist_simulator.byte test/exemple.net

L'option -n <steps> permet de choisir le nombre de steps que fera le simulateur











